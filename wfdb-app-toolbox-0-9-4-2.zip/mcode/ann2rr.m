function varargout=ann2rr(varargin)
%
% [RR,tms,commandOut]=ann2rr(recordName,annotator,N,N0,consecutiveOnly,commandExec,commandArg)
%
%    Wrapper to WFDB ANN2RR:
%         http://www.physionet.org/physiotools/wag/ann2rr-1.htm
%
%    Reads a WFDB record and Annotation file to return:
%
%
% RR     
%       Nx1 vector of integers representing the duration of the RR
%       interval in samples.
%
% tms     
%       Nx1 vector of integers representing the begining of the RR
%       interval in samples.%
%
% commandOut
%       A cell array list of output arguments if the 'commandExec' flag is
%       set (all other input arguments and output arguments are ignored)
%       see below. 
%
% Required Parameters:
%
% recorName
%       String specifying the name of the record in the WFDB path or
%       in the current directory.
%
% annotator  -
%       String specifying the name of the annotation file in the WFDB path or
%       in the current directory.
%
% Optional Parameters are:
%
% N 
%       A 1x1 integer specifying the sample number at which to stop reading the 
%       record file (default read all = N).
% N0 
%       A 1x1 integer specifying the sample number at which to start reading the 
%       annotion file (default 1 = begining of the record).
%
% consecutiveOnly 
%       A 1x1 boolean. If true, prints intervals between consecutive valid
%       annotaions only (default =true).
%
% commandExec
%      A String flag with value set to 'commandExec'. If this is true, all
%      other input arguments will be ignored and the native code will be
%      executed with the input arguments that follow this flag. The order
%      in which this argument is passsed does not matter. The function will
%      ignore all other commands. Use this argument if there is a feature
%      in the native tools that have not been implemented yet in MATLAB.
%      If the feature is implemented, it might be more efficient to use the
%      standard MATLAB signature instead. 
%
% commandArg
%     A cell array list of string to pass to the native code input
%     arguments. This list should always follow 'commandExec'.
%
% Written by Ikaro Silva, 2013
% Last Modified: -
% Version 1.0
%
% Since 0.0.1
% %Example
%[rr,tm]=ann2rr('challenge/2013/set-a/a01','fqrs');
%
%
% %Example 2- Using the native library API
% commandOut=ann2rr('commandExec',{'-r','challenge/2013/set-a/a01','-a','fqrs'})




persistent javaWfdbExec

if(~wfdbloadlib)
    %Add classes to dynamic path
    wfdbloadlib;
end

if(isempty(javaWfdbExec))
    %Load the Java class in memory if it has not been loaded yet
    javaWfdbExec=org.physionet.wfdb.Wfdbexec('ann2rr');
end

%Set default pararamter values
inputs={'recordName','annotator','N','N0','consecutiveOnly'};
outputs={'data(:,2)','data(:,1)'};
N=[];
N0=1;
consecutiveOnly=1;
for n=1:nargin
    if(~isempty(varargin{n}))
        eval([inputs{n} '=varargin{n};'])
    end
end

N0=num2str(N0-1); %-1 is necessary because WFDB is 0 based indexed.
wfdb_argument={'-r',recordName,'-a',annotator,'-f',['s' N0]};

if(~isempty(N))
    wfdb_argument{end+1}='-t';
    %-1 is necessary because WFDB is 0 based indexed.
    wfdb_argument{end+1}=['s' num2str(N-1)];
end
    
if(consecutiveOnly)
    wfdb_argument{end+1}='-c';
end
wfdb_argument{end+1}='-V';

data=javaWfdbExec.execToDoubleArray(wfdb_argument);
for n=1:nargout
        eval(['varargout{n}=' outputs{n} ';'])
end


