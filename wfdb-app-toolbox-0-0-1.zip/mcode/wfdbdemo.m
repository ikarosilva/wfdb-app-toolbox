
%This script will test the installation of the WFDB Application Toolbox
%
% Written by Ikaro Silva, 2013
%
% Version 1.0
% Since 1.0
%
% See also wfdb, rdsamp

clc;clear all;close all
fprintf('***Starting test of the WFDB Application Toolbox (CopyLeft)\n')
fprintf('\tIf you have any problems with this test, please contact: \n')
fprintf('\t\twfdb-matlab-support@physionet.org \n\n\n')

%Test 1- Test that libraries, classes, and mcode are in path and are
%loaded properly
fprintf('**Printing Configuration Settings:\n')
wfdbpath=which('wfdbloadlib');
fprintf('**\tWFDB App Toolbox Path is:\n');
fprintf('\t\t%s\n',wfdbpath);
[isloaded,config]=wfdbloadlib;
nsm=fieldnames(config);

for n=1:length(nsm)
    fprintf(['\t' nsm{n} ':  '])
    eval(['fld=config.' nsm{n} ';'])
    fprintf([fld '\n'])
end


%Test 2- Test2 simple queries to PhysioNet servers
%loaded properly. This should work regardless of the libcurl installation
fprintf('**Querying PhysioNet for available databases...\n')
db_list=physionetdb;
N=length(db_list);
fprintf(['\t' num2str(N) ...
    ' databases available for download (type ''help physionetdb'' for more info).\n'])


%Test 3- Test ability to read local data and annotations
fprintf('**Reading local example data and annotation...\n')
sampleLength=10000;
fname=[config.MATLAB_PATH filesep 'example/a01'];
[tm, signal]=rdsamp(fname,[],sampleLength);
plot(tm,signal(:,1),'r-','LineWidth',1);grid on; hold on
[ann]=rdann(fname,'fqrs',[],sampleLength);
plot(tm(ann),signal(ann,1),'bo','MarkerSize',2,'MarkerFaceColor','b',...
    'LineWidth',5)
legend('Abdominal ECG','Annotated Fetal QRS')



%Test 4- Test ability to write local annotations
fprintf('**Calculating maternal QRS sample data ...\n')
curdir=pwd;

wqrs(fname,[],[],1)
[Mann]=rdann(fname,'wqrs',[],sampleLength);
plot(tm(Mann),signal(Mann,1),'g^','MarkerSize',2,'MarkerFaceColor','g',...
    'LineWidth',5)
legend('Abdominal ECG','Annotated Fetal QRS','Estimated Maternal QRS')
title(['Sample Data DB: challenge/2013/set-a/'])

fprintf('***Done Testing Toolbox!!\n')