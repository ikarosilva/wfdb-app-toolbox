function varargout=maprecord(varargin)
%
% [mapvalues]=maprecord(names,executeCommand,N,N0,Nthreads)
%
% 
% Performs multithreaded batch processing of WFDB records usin the executable
% command 'executeCommand'. The MAPRECORD reads WFDB records in multithreaded mode,
% passing the data as a matrix to the standard input of 'executeCommand' 
% getting the results back as a vector for each record from the standard output of
% the 'executeCommand' (see examples below for detail). The
% 'executeCommand' should ouput Mx1 doubles for each record processed.
%
%
% Required Parameters:
%
% names
%       If a single string, specifies a PhysioNet database name in which to 
%       do the processing. The PhysioNet database has to be a valid one as 
%       give by the ouput of PHYSIONETDB. If names is a Nx1 cell, each cell
%       should represent a record name (with the databse path) that can be 
%       read directly by RDSAMP.
%
% executeCommand
%       The full path and name of the executable installed on your system
%       that will be run on each record data. The 'executeCommand' 
%       should ouput Mx1 doubles for each record processed.
%
%
% Optional Parameters are:
%
% N
%       A 1x1 integer specifying the sample number at which to stop reading the
%       record file (default read all = N).
% N0
%       A 1x1 integer specifying the sample number at which to start reading the
%       record file (default 1 = first sample).
%
% Nthreads
%       A 1x1 integer specifying the number of threads to use for 
%       processing (between 1 and the number of processors in your system).
%       Default is the number of processor on your system. 
%
%
% Ouput parameters:
%
% mapvalues
%       A NxM matrix of doubles. Where each row is the ouput of running the
%       'executeCommand' on a single record from 'names' (N records) and
%       the columns are from obtained from the standard output 'executeCommand' 
%       (which gives Mx1 doubles for each record processed). 
%        
% Written by Ikaro Silva, 2013
% Last Modified: 
% Version 1.0
%
% Since 0.9.1
%
% See also RDSAMP, PHYSIONETDB
%
%%Example 1- Single thread execution of DFA on the 'aami-ec13' database
%tic;[mapvalues]=maprecord('aami-ec13','/usr/lib/dfa',[],[],1);toc
%
% %Example 2- Maximum Multi-thread execution
%tic;[mapvalues]=maprecord('aami-ec13','/usr/lib/dfa');toc


persistent javaWfdbExec

if(~wfdbloadlib)
    %Add classes to dynamic path
    wfdbloadlib;
end

if(isempty(javaWfdbExec))
    %Load the Java class in memory if it has not been loaded yet
    javaWfdbExec=org.physionet.wfdb.concurrent.MapRecord;
end

%Set default pararamter values
inputs={'names','executeCommand','N','N0','Nthreads'};
outputs={'mapvalues'};
N=[];
N0=[];
Nthreads=[]; 
for n=1:nargin
    if(~isempty(varargin{n}))
        eval([inputs{n} '=varargin{n};'])
    end
end


%If N is empty, it is the entire dataset. We should ensure capacity
%so that the fetching will be more efficient.
if(isempty(N))
    [siginfo,~]=wfdbdesc(recordName);
    if(~isempty(siginfo))
        N=siginfo(1).LengthSamples;
    else
        warning('Could not get signal information. Attempting to read signal without buffering.')
    end
end

if(~isempty(N))
    %Its is possible where this is not true in rare cases where
    %there is no signal length information on the header file
    wfdb_argument{end+1}='-t';
    wfdb_argument{end+1}=['s' num2str(N)];
    ListCapacity=N-N0;
end

if(~isempty(ListCapacity))
    %Ensure list capacity if information is available
    javaWfdbExec.setDoubleArrayListCapacity(ListCapacity);
end

if(~isempty(signalList))
    wfdb_argument{end+1}='-s ';
    %-1 is necessary because WFDB is 0 based indexed.
    wfdb_argument{end+1}=[num2str(signalList-1)];
end
if(nargout>2)
    if(isempty(siginfo))
        [siginfo,~]=wfdbdesc(recordName);
    end
    if(~isempty(siginfo))
    %Its is possible where this is not true in rare cases where
    %there is no signal length information on the header file
        if(isempty(signalList))
            Fs=siginfo(1).SamplingFrequency;
        else
            Fs=siginfo(signalList(1)).SamplingFrequency;
        end
        Fs=str2double(regexprep(Fs,'Hz',''));
    end
end

data=javaWfdbExec.execToDoubleArray(wfdb_argument);
for n=1:nargout
    eval(['varargout{n}=' outputs{n} ';'])
end


