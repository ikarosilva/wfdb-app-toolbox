function varargout=wfdbdesc(varargin)
%
% [siginfo,Fs]=wfdbdesc(recordName)
%
%    Wrapper to WFDB WFDBDESC:
%         http://www.physionet.org/physiotools/wag/wfdbde-1.htm
%
% Reads a WFDB record metadata and returns:
%
%
% signal
%       Nx1 vector of siginfo structures with the following fields:
%
%       LengthSamples           : Number of samples in record (integer)
%       LengthTime              : Duration of record  (String WFDB Time)
%       RecordName              : Record name (String)
%       RecordIndex             : Record Index (Integer)
%       Description             : Signal Description (String)
%       SamplingFrequency       : Sampling Frequency w/ Units (String)
%       File                    : File name (String)
%       SignalIndex             : Zero Based Signal Index (Integer)
%       StartTime               : Start Time (String WFDB Time)
%       Group                   : Group (Integer)
%       AdcResolution           : Bit resolution of the singal (String)
%       AdcZero                 : Physical value for 0 ADC (double)
%       Baseline                : Physical zero level of signal (Integer)
%       CheckSum                : 16-bit checksum of all samples (Integer)
%       Format                  : WFDB's Format of the samples (String)
%       Gain                    : ADC units per physical unit (String)
%       InitialValue            : Value of sample 1 in the signal (Integer)
%       IO                      : IO Type  (String)
%
% Fs   (Optional)
%       Nx1 vector of doubles representing the sampling frequency of each
%       signal in Hz (if the 'SamplingFrequency' string is parsable).
%
% Required Parameters:
%
% recorName
%       String specifying the name of the record in the WFDB path or
%       in the current directory.
%
%
% %Example
% siginfo=wfdbdesc('challenge/2013/set-a/a01')
%
%
% Written by Ikaro Silva, 2013
%
% Modified by Ikaro Silva, December 3, 2014
%
% Version 2.0
%
% Since 0.0.1
% See also RDSAMP

%endOfHelp

persistent javaWfdbExec config
if(isempty(javaWfdbExec))
    [javaWfdbExec,config]=getWfdbClass('wfdbdesc');
end

%Set default pararamter values
inputs={'recordName'};
outputs={'siginfo','Fs'};

for n=1:nargin
    if(~isempty(varargin{n}))
        eval([inputs{n} '=varargin{n};'])
    end
end

wfdb_argument={recordName};
data=char(javaWfdbExec.execToStringList(wfdb_argument));
lines=[1 strfind(data,',')];
siginfo=[];
Fs=[];
L=length(lines);

%Define record Wide parameters
RecordName=[];
StartTime =[];
LengthSamples=[];
LengthTime=[];
SamplingFrequency =[];

%index for each signal
ind=0;
for n=1:L-1
    str=(data(lines(n):lines(n+1)-1));
    str=str(2:end); %Remove comma
    if(~isempty(strfind(str,'Record')))
        C=textscan(str,'%s%s');
        RecordName=C{2};
    elseif(~isempty(strfind(str,'Starting time:')))
        C=textscan(str,'%s:%s');
        StartTime =C{2};
    elseif(~isempty(strfind(str,'Length:')))
        %Should happen only once
        ind1=strfind(str,'(');
        ind2=strfind(str,'sample intervals)');
        LengthSamples=str2num(str(ind1:ind2));
        C=textscan(str,'%s%s%s%s%s');
        LengthTime=C{2};
    elseif(~isempty(strfind(str,'Sampling frequency:')))
        C=textscan(str,'%s%s%u%s');
        SamplingFrequency =C{3};
    elseif(~isempty(strfind(str,'Group')))
        %In this case we are seeing a new signal, enter record wide
        %fields as well
        ind=ind+1;
        C=textscan(str,'%s%d');
        siginfo(ind).Group=C{2};
        siginfo(ind).RecordName=RecordName;
        siginfo(ind).StartTime =StartTime;
        siginfo(ind).LengthSamples=LengthSamples;
        siginfo(ind).LengthTime=LengthTime;
        siginfo(ind).SamplingFrequency =SamplingFrequency;
        Fs(end+1)=SamplingFrequency;
    elseif(~isempty(strfind(str,'Signal')))
        C=textscan(str,'%s%d:');
        siginfo(ind).SignalIndex=C{2};
    elseif(~isempty(strfind(str,'File:')))
        C=textscan(str,'%s%s');
        siginfo(ind).File=C{2};
    elseif(~isempty(strfind(str,'Description:')))
        C=textscan(str,'%s%s');
        siginfo(ind).Description=C{2};
    elseif(~isempty(strfind(str,'Gain:')))
        C=textscan(str,'%s%s%s');
        siginfo(ind).Gain=[C{2} C{3}];
    elseif(~isempty(strfind(str,'Initial value:')))
        C=textscan(str,'%s:%d');
        siginfo(ind).InitialValue=C{2};
    elseif(~isempty(strfind(str,'Storage format:')))
        C=textscan(str,'%s:%s');
        siginfo(ind).Format=C{2};
    elseif(~isempty(strfind(str,'I/O:')))
        C=textscan(str,'%s:%s');
        siginfo(ind).IO=C{2};
    elseif(~isempty(strfind(str,'ADC resolution:')))
        C=textscan(str,'%s:%s');
        siginfo(ind).AdcResolution=C{2};
    elseif(~isempty(strfind(str,'ADC zero:')))
        C=textscan(str,'%s:%f');
        siginfo(ind).AdcZero=C{2};
    elseif(~isempty(strfind(str,'Baseline:')))
        C=textscan(str,'%s:%d');
        siginfo(ind).Baseline=C{2};
    elseif(~isempty(strfind(str,'Checksum:')))
        C=textscan(str,'%s:%d');
        siginfo(ind).CheckSum=C{2};
    else
        %Skip unused field
    end
    
end

for n=1:nargout
    eval(['varargout{n}=' outputs{n} ';'])
end


